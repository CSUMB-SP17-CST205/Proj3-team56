food = {
"burger_kings_medium_fries" : {None : 404,'Calories': 380, 'Sodium': '570 mg', 'Carbohydrates':'53 g', 'Total Sugar':'0 g', 'Protein':'5 g', 'Total Fat':'150 g', 'Saturated Fat': '3 g', 'Trans Fat': '0 g', 'Cholesterol': '0 mg'},
    
"burger_kings_hot_dog" : {None : 404,'Calories': 310, 'Sodium': '960 mg', 'Carbohydrates':'32 g', 'Total Sugar':'10 g', 'Protein':'11 g', 'Total Fat':'16 g', 'Saturated Fat': '6 g', 'Trans Fat': '1 g', 'Cholesterol': '30 mg'},

"burger_kings_whopper" : {None : 404,'Calories': 630, 'Sodium': '810 mg', 'Carbohydrates':'49 g', 'Total Sugar':'11 g', 'Protein':'26 g', 'Total Fat':'38 g', 'Saturated Fat': '11 g', 'Trans Fat': '1.5 g', 'Cholesterol': '85 mg'},

"innouts_double_double" : {None : 404,'Calories': 650, 'Sodium': '1400 mg', 'Carbohydrates':'38 g', 'Total Sugar':'9 g', 'Protein':'35 g', 'Total Fat':'40 g', 'Saturated Fat': '18 g', 'Trans Fat': '1 g', 'Cholesterol': '120 mg'},

"innouts_fries" : {None : 404,'Calories': 395, 'Sodium': '245 mg', 'Carbohydrates':'54 g', 'Total Sugar':'0 g', 'Protein':'7 g', 'Total Fat':'18 g', 'Saturated Fat': '5 g', 'Trans Fat': '0 g', 'Cholesterol': '0 mg'},

"mcdonalds_big_mac" : {None : 404,'Calories': 540, 'Sodium': '1040mg', 'Carbohydrates': '45g',  'Total Sugar': '9g', 'Protein': '25g', 'Total Fat': '29g', 'Saturated Fat': '10g', 'Trans Fat': '1.5g','Cholesterol': '75mg'},

"mcdonalds_double_quarter_pounder_with_cheese" : {None : 404,'Calories': 750, 'Sodium': '1280mg', 'Carbohydrates': '42', 'Total Sugar': '10g', 'Protein': '48g', 'Total Fat': '43g', 'Saturated Fat': '19g', 'Trans Fat': '3g', 'Cholesterol': '160mg'},

"mcdonalds_cheeseburger" : {None : 404,'Calories': 300, 'Sodium': '680mg', 'Carbohydrates': '33g', 'Total Sugar': '7g', 'Protein': '15g', 'Total Fat': '12g', 'Saturated Fat': '6g', 'Trans Fat': '1g', 'Cholesterol': '40mg'}
}

